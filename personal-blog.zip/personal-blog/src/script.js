// Theme Toggle Functionality
const themeToggle = document.getElementById('theme-toggle');
const body = document.body;

// Check for saved theme in localStorage
const savedTheme = localStorage.getItem('theme');
if (savedTheme) {
  body.classList.add(savedTheme);
  updateButtonText();
}

// Toggle Theme
themeToggle.addEventListener('click', () => {
  body.classList.toggle('dark-theme');
  localStorage.setItem('theme', body.classList.contains('dark-theme') ? 'dark-theme' : '');
  updateButtonText();
});

// Update Button Text
function updateButtonText() {
  if (body.classList.contains('dark-theme')) {
    themeToggle.textContent = '☀️ Light Mode';
  } else {
    themeToggle.textContent = '🌙 Dark Mode';
  }
}

// Journal Entry Functionality
const journalForm = document.getElementById('journal-form');
const journalInput = document.getElementById('journal-input');
const journalEntries = document.getElementById('journal-entries');

journalForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const entryText = journalInput.value.trim();
  if (entryText) {
    const entry = document.createElement('div');
    entry.classList.add('entry');
    entry.textContent = `📅 ${new Date().toLocaleDateString()}: ${entryText}`;
    journalEntries.appendChild(entry);
    journalInput.value = '';
  }
});

// Welcome Alert
window.onload = function() {
  alert("Welcome to Mindful Circuits! 🎉 Let's explore together.");
};